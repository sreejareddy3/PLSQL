create or replace trigger kkk
before insert or update or delete on customer
for each row when(new.id>0)
declare
sal_diff number(10);
begin
sal_diff:=:old.salary-:new.salary;
dbms_output.put_line('The old salary is'||:old.salary);
dbms_output.put_line('The new salary is'||:new.salary);
dbms_output.put_line('The salary difference is'||sal_diff);
end;
/


