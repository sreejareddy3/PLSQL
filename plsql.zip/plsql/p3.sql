declare
total_row number(10);
begin
update customer set salary=salary+500;
if sql%notfound then
dbms_output.put_line('no rows');
elsif sql%found then
total_row:=sql%rowcount;
dbms_output.put_line(total_row);
end if;
end;
/